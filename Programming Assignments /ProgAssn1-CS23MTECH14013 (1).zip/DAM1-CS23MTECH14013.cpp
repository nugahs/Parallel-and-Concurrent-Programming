#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <cmath>
#include <semaphore.h>
#include <unistd.h>
#include <string>
#include <fstream>
#include <vector>
#include <memory.h>
#include <chrono>
#include <mutex>
#include <atomic>
#include <set>
using namespace std;
using namespace std::chrono;
set<int> primeNumber;
unsigned long long powOfTen = 8;  // For SIZE = 10 ^ n 
int NUM_THREADS;

/////////////// FUNCTION THAT CHECKS WHETHER THE NUMBER IS PRIME OR NOT ////////////////////
bool isPrime(unsigned long int n)
{
    if (n <= 1)
        return false;
    for (int i = 2; i <= sqrt(n); i++)
        if (n % i == 0)
            return false;
  
    return true;
}
std::ofstream outputFile1("Primes-DAM1.txt");
std::atomic<unsigned long int> ctr;  ///// ATOMIC VARIABLE DECLARATION 
void *printPrime(void *threadid)
{

    auto tid = *(int*)threadid;
    unsigned long int num = 0;
    unsigned long int limit = pow(10, powOfTen);
    
    while(num < limit)
    {
        num = ctr.fetch_add(1, std::memory_order_seq_cst);
        if(isPrime(num))
        {
            //primeNumber.insert(num);
         if (!outputFile1.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
          outputFile1 << num << endl;

             // cout<<num<<"    " ;
        }          
        } 
    //    outputFile1.close();
    } 
    

  
int main()
{
    //////////////READING FROM INPUT FILE //////////////
    fstream in;
    in.open("inp-params.txt", fstream::in);
    if(!in.is_open()) {
        cerr<<"Input file not open\n";
        return 0;
    }
    in>>powOfTen>>NUM_THREADS;            // reading from "input.txt"
    in.close();
    ////////////READING OPERATION COMPLETED///////////

    //////////////// MULTI THREADING ////////////////
    int threadIds[NUM_THREADS];
    pthread_t threads[NUM_THREADS];
    auto startTime=high_resolution_clock::now();
    for( int i = 0; i < NUM_THREADS; i++ ) 
    {
        threadIds[i] = i+1;
        pthread_create(&threads[i], NULL, printPrime, &threadIds[i]); 
    }
     
    for(int i = 0; i < NUM_THREADS; i++)     
    {
        pthread_join(threads[i], NULL);
    }

    auto stopTime=high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stopTime-startTime);
    //unsigned long int limit = pow(10, powOfTen);
    //  set<int> :: iterator it;
    //  for(it = primeNumber.begin(); it != primeNumber.end() ; it++) {
    // // cout << *it << endl;
    // if (!outputFile1.is_open())
    //       {
    //       std::cerr << "Failed to open files." << std::endl;
    //       //return 1;
    //      }
    //       outputFile1 << *it << endl;
    // }


    std::ofstream outputFile2("Times.txt");
    if (!outputFile2.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
    outputFile2<< duration.count()<<" millisec\n";
    return 0;
}
