#include <iostream>
#include <cstdlib>
#include <set>
#include <pthread.h>
#include <cmath>
#include <typeinfo>
#include <fstream>
#include <chrono>

using namespace std;
using namespace std::chrono;
std::ofstream outputFile2("Times2.txt");
int powOfTen;
int NUM_THREADS;
set<int> primeNumber;

class Params{
  public:
    int threadNo;
    int count;
    Params(int inThreadNo,int inCount):
    threadNo(inThreadNo),count(inCount){}
};

   bool isPrime(int n)
  {
   
    if (n <= 1)
        return false;
    for (int i = 2; i<=sqrt(n); i++)
        if (n % i == 0)
            return false;
  
    return true;
   }
//int flag =0;
// std::atomic<unsigned long int> ctr;
   void *printPrime(void *param)
  {
    Params *p = (class Params *)param;
    int tno = p->threadNo;
  //  int j=0;
    int limit= pow(10,powOfTen);
  //   while(ctr<limit)
  //  {
  //   ctr= j*NUM_THREADS + tno;
  //   if((ctr==2) || isPrime(ctr))
  //   {
  //      // primeNumber.insert(i);
  //      cout << "  "<<ctr<<" ";
  //   }
  //   j++;
  // }
   for(int k=tno;k<limit;k+=NUM_THREADS)
   {
    if(k%2==0 && k!=2)
    continue;
    else
    {
      if(isPrime(k))
      {
        primeNumber.insert(k);
        //cout<<" "<<k<<"  ";
      }
    }
   }
 }

int main()
{
  ////////////Reading from file/////////////
  fstream in;
    in.open("inp-params.txt", fstream::in);

    if(!in.is_open()) {
        cerr<<"Input file not open\n";
        return 0;
    }
    in>>powOfTen>>NUM_THREADS;            // reading from "input.txt"
    in.close();

  pthread_t threads[NUM_THREADS+1];

  auto startTime=high_resolution_clock::now();

  int limit= pow(10,powOfTen);
  for( int i = 0; i <NUM_THREADS; i++ ) 
  {
      Params *p = new Params(i+1, limit/NUM_THREADS);
    
      pthread_create(&threads[i+1], NULL , printPrime,p);
      
   }
    for(int i = 0; i < NUM_THREADS; i++) 
    {
        pthread_join(threads[i],NULL);
    }

    auto stopTime=high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stopTime-startTime);

   std::ofstream outputFile1("Primes-SAM1.txt");
   set<int> :: iterator it;

  // cout << "elements inside set at 23 56:\n";
  for(it = primeNumber.begin(); it != primeNumber.end(); it++) {
    // cout << *it << endl;
    if (!outputFile1.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
          outputFile1 << *it << endl;
   }
  // pthread_exit(NULL);
  
    if (!outputFile2.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
    outputFile2<< duration.count()<<" millisec\n";
    outputFile2<<"\n"<<"Time duration: "<< duration.count()<<" millisec ";
 return 0;
}