How to run the programs using terminal?

Set the path to where the program file is 

To compile use the command :
g++ -std=c++20 -pthread sam.cpp

To run use the command :
./a.out


Note :
In DAM1 program the prime numbers get printed one in a line but if you will try 
to print using spaces then there can be discrepancy.  
