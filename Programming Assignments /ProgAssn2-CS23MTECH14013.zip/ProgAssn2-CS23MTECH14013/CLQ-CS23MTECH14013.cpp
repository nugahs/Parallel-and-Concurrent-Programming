#include <iostream>
#include <mutex>
#include <stdexcept>
#include <pthread.h>
#include <random>
#include <chrono>
#include <vector>
#include <unistd.h>
#include <fstream>

using namespace std;

template <typename T>
class LockBasedQueue {
private:
    int head, tail;
    int capacity; // Add the capacity member variable
    T* items;
    std::mutex lock;

public:
    LockBasedQueue(int capacity) : head(0), tail(0), capacity(capacity), items(new T[capacity]) {}

    ~LockBasedQueue() 
    {
        delete[] items;
    }

    void enq(T x) 
    {
        std::lock_guard<std::mutex> guard(lock);
        if (tail - head == capacity) {
            throw std::overflow_error("Queue is full");
        }
        items[tail % capacity] = x;
        tail++;
    }

    T deq() 
    {
        std::lock_guard<std::mutex> guard(lock);
        if (tail == head) 
        {
            throw std::underflow_error("Queue is empty");
        }
        T x = items[head % capacity];
        head++;
        return x;
    }
};
///////////////////GLOBAL VARIABLES //////////////////////
int numThreads; //  desired number of threads
int numOps; // desired number of operations
int lambda;
double rndLt;
    
std::vector<long> thrTimes(numThreads+1,-1);
std::vector<long> enqTimes(numThreads+1,0); // STORES TIME TAKEN BY THREAD 0 TO PERFORM ALL ENQ OPERATIONS AT INDEX 0 , TIME TAKEN BY THREAD 1 TO PERFORM ALL ENQ OPERATIONS AT INDEX 1, AND SO ON
std::vector<long> deqTimes(numThreads+1,-1);
    
LockBasedQueue<int> queue(1000);
std::ofstream outputFile1("CLQ-out.txt");

class Params{
  public:
    int threadNo;
    //int count;
    Params(int inThreadNo):
    threadNo(inThreadNo)
    //,count(inCount)
    {}
};


void *testThread(void *param)
{
   Params *p = (class Params *)param;
   int tno = p->threadNo;
   // std::cout<< tno<<"   ";

   
   std::default_random_engine uniRandGen(std::chrono::system_clock::now().time_since_epoch().count());
   std::default_random_engine expRandGen(std::chrono::system_clock::now().time_since_epoch().count());
   std::uniform_real_distribution<double> uniRandDist(0.0, 1.0);
   std::exponential_distribution<double> expRandDist(lambda);
    double p_rand;
    for (int i = 0; i < numOps ; i++) {
         p_rand = uniRandDist(uniRandGen);
         
          if (p_rand < rndLt) 
          {
             try
            {
                 auto startTime = std::chrono::high_resolution_clock::now();
                 queue.enq(i);
                 auto endTime = std::chrono::high_resolution_clock::now();
                 enqTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
                 thrTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
            }
            
             catch(const std::exception& e)
            {
               continue;
            }
          }
          else
          {
            try {
            auto startTime = std::chrono::high_resolution_clock::now();
            int d= queue.deq();
            auto endTime = std::chrono::high_resolution_clock::now();
            thrTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
            deqTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();

          
             }
             catch (const std::underflow_error& e) 
                {
                    // Handle underflow error (queue is empty)
                    // ignore  exception 
                    continue;
                }
          }
           // Simulate performing other tasks using sleep
            double sleepTime = expRandDist(expRandGen);
            usleep(static_cast<unsigned int>(sleepTime * 1000));

    }
            
}

void computeStats() {
        long totalEnqTime = 0;
        long totalDeqTime = 0;
        long totalOpTime = 0;

        for (size_t i = 0; i < thrTimes.size(); i++) 
        {
            totalOpTime += thrTimes[i];
            totalDeqTime+=deqTimes[i];
            totalEnqTime+=enqTimes[i];
        }

        int numThreads = thrTimes.size();
        std::cout << "Average time for enq operations: " << static_cast<double>(totalEnqTime) / (numThreads*numOps) << " nanoseconds." << std::endl;
        std::cout << "Average time for deq operations: " << static_cast<double>(totalDeqTime) / (numThreads*numOps) << " nanoseconds." << std::endl;
        std::cout << "Average time for all operations: " << static_cast<double>(totalOpTime) / (numThreads*numOps) << " nanoseconds." << std::endl;
        
        /////////////// WRITING in OUTPUT FILE ////////////
        if (!outputFile1.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
        
         }
          outputFile1 << ((totalOpTime) / (numThreads*numOps)) << endl; // Average time for all operations by all threads
      

    
    }


int main() {
     ////////////Reading from file/////////////
    fstream in;
    in.open("inp-params.txt", fstream::in);

    if(!in.is_open()) {
        cerr<<"Input file not open\n";
         return 0;
    }
    in>>numThreads>>numOps>>rndLt>>lambda;
         // reading from "input.txt"
    in.close();
  
    for(int i=0; i<numThreads; i++)
    {
        deqTimes.push_back(-1);
        thrTimes.push_back(0);
        enqTimes.push_back(0);
    }


    ///////////////MULTI THREADING////////////////////
    pthread_t threads[numThreads];

    for( int i = 0; i <numThreads; i++ ) 
    {
      Params *p = new Params(i); 
      pthread_create(&threads[i+1], NULL , testThread,p);
      
    }
   for(int i = 0; i < numThreads; i++) 
    {
        pthread_join(threads[i],NULL);    
    }
    ////////////////////////////////////////////////

    computeStats();

    /////////////// WRITING OUTPUT FILE ////////////
    outputFile1 << "Average Time taken (in nanosecs) by each thread to perform numOps operations \n i.e values of thrTimes[] are :" << endl;
    for(int i = 0; i < numThreads; i++) 
    {
        if (!outputFile1.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
          outputFile1 << (thrTimes[i]/numOps) << "  ";
      
    }
    ///////////////////////////////////////////////
    return 0;
}
