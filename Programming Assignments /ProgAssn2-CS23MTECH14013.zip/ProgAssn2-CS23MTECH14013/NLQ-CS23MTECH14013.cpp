#include <iostream>
#include <atomic>
#include <array>
#include <pthread.h>
#include <random>
#include <chrono>
#include <unistd.h>
#include <vector>
#include <stdexcept>
#include <climits>
#include <fstream>

using namespace std;

template <typename T>
class HWQueue 
{
private:
    enum { CAPACITY = 10000 }; 
    std::array<std::atomic<T*>, CAPACITY> items;
    std::atomic<int> tail;

public:
    HWQueue() : tail(0) 
    {
        for (int i = 0; i < CAPACITY; i++)
        {
            items[i].store(nullptr);
        }
    }

    void enq(T x) 
    {
        int i = tail.fetch_add(1);
        items[i % CAPACITY].store(new T(x));
    }

    T deq() 
    {
        while (true) 
        {
            int range = tail.load();
            for (int i = 0; i < range; i++)
            {
                T* valuePtr = items[i % CAPACITY].exchange(nullptr, std::memory_order_seq_cst);
                if (valuePtr != nullptr) 
                {
                    T value = *valuePtr;
                    delete valuePtr;
                    return value;
                }
                else
                {
                    // What happens when there are no items in the queue?
                    // deq will never break out of the infinite loop
                    // When no items are found its underflow, have to return
                    // something to break out of the infinite loop. Here I return
                    // INT_MIN.
                    return INT_MIN;
                }
            }
        }
    }
};

///////// GLOBAL VARIABLES DECLARATION ////////////
int numThreads;
int lambda;
int numOps;
double rndLt;
std::vector<long> thrTimes(numThreads+1,0);
std::vector<long> enqTimes(numThreads+1,0);
std::vector<long> deqTimes(numThreads+1,0);

HWQueue<int> queue;
std::ofstream outputFile1("NLQ-out.txt");
////////////////////////////////////////////////////


// THIS WILL BE USED IN ASSIGNING UNIQUE INTEGER THREAD ID TO EACH THREAD
class Params
{
  public:
    int threadNo;
    Params(int inThreadNo):
    threadNo(inThreadNo){}
};


// EVERY THREAD WILL EXECUTE BELOW FUNCTION
void *testThread(void *param)
 {

    Params *p = (class Params *)param;
    int tno = p->threadNo; // EACH THREAD HAS BEEN ASSIGNED INTEGER THREAD ID
   
    std::default_random_engine uniRandGen(std::chrono::system_clock::now().time_since_epoch().count());
    std::default_random_engine expRandGen(std::chrono::system_clock::now().time_since_epoch().count());
    std::uniform_real_distribution<double> uniRandDist(0.0, 1.0);
    std::exponential_distribution<double> expRandDist(lambda);
    double p_rand;

    for (int i = 0; i < numOps ; i++)
     {
        p_rand = uniRandDist(uniRandGen);
        if (p_rand < rndLt) 
        {
            try
            {
                auto startTime = std::chrono::high_resolution_clock::now();
                queue.enq(i);
                auto endTime = std::chrono::high_resolution_clock::now();
                enqTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
                thrTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
            }
            catch(const std::exception& e)
            {
                continue;
            }
        }
        else
        {
          
            try {
                auto startTime = std::chrono::high_resolution_clock::now();
                int d = queue.deq();
                auto endTime = std::chrono::high_resolution_clock::now();
                thrTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
                deqTimes[tno] += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
            }
            catch (const std::underflow_error& e) {
            // Handle underflow error (queue is empty)
            // ignore  exception 
                continue;
            }
        }
        // Simulate performing other tasks using sleep
        double sleepTime = expRandDist(expRandGen);
        usleep(static_cast<unsigned int>(sleepTime * 1000));
    }
}
void computeStats() {
        long totalEnqTime = 0;
        long totalDeqTime = 0;
        long totalOpTime = 0;

        for (size_t i = 0; i < thrTimes.size(); i++) 
        {
            totalOpTime += thrTimes[i];
            totalDeqTime+=deqTimes[i];
            totalEnqTime+=enqTimes[i];
        }

        int numThreads = thrTimes.size();
        std::cout << "Average time for enq operations: " << static_cast<double>(totalEnqTime) / (numThreads*numOps) << " nanoseconds." << std::endl;
        std::cout << "Average time for deq operations: " << static_cast<double>(totalDeqTime) / (numThreads*numOps) << " nanoseconds." << std::endl;
        std::cout << "Average time for all operations: " << static_cast<double>(totalOpTime) / (numThreads*numOps) << " nanoseconds." << std::endl;
        
        /////////////// WRITING in OUTPUT FILE ////////////
        if (!outputFile1.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
          outputFile1 << ((totalOpTime) / (numThreads*numOps)) << endl; // Average time for all operations by all threads
      

    
    
    }
int main() 
    {
    ////////////// READING FROM FILE ////////////////
    fstream in;
    in.open("inp-params.txt", fstream::in);

    if(!in.is_open()) {
        cerr<<"Input file not open\n";
         return 0;
    }
    in>>numThreads>>numOps>>rndLt>>lambda;
         
    in.close();
    ///////// READING OPERATION COMPLETED/////////////

    /////////////INITIALIZING GLOBAL VECTORS WHICH ARE BEING USED FOR STORING TIME 
    for(int i=0; i<numThreads; i++) 
    {
        deqTimes.push_back(-1);
        thrTimes.push_back(0);
        enqTimes.push_back(0);
    }
    

    //////////////////   MULTI THREADING /////////////////////
    pthread_t threads[numThreads];

    for( int i = 0; i <numThreads; i++ )
    {
        Params *p = new Params(i); 
        pthread_create(&threads[i], NULL , testThread,p);
    }

    for(int i = 0; i < numThreads; i++){
        pthread_join(threads[i], NULL);
    }
    /////////////////////////////////////////////////////////

    computeStats();

    /////////////// WRITING OUTPUT FILE ////////////
    outputFile1 << "Average Time taken (in nanosecs) by each thread to perform numOps operations \n i.e values of thrTimes[] are :" << endl;
    for(int i = 0; i < numThreads; i++) 
    {
        if (!outputFile1.is_open())
          {
          std::cerr << "Failed to open files." << std::endl;
          //return 1;
         }
          outputFile1 << (thrTimes[i]/numOps) << "  ";
      
    }
    ///////////////////////////////////////////////
    return 0;
}
