How to run the programs using terminal?

Set the path to where the program file is 

To compile use the command :
g++ -std=c++20 -pthread <filename>.cpp

To run use the command :
./a.out
 

// Output file will be generated and along with that
 You will see output on terminal those are stats printed by comput stats function 
