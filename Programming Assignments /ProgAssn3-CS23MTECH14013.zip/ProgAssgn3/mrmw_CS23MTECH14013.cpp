#include <iostream>
#include <cstddef>
#include <random>
#include <chrono>
#include <pthread.h>
#include<unistd.h>
#include <fstream>
//#define MIN_VALUE=0
using namespace std;
using namespace std::chrono;


template <typename T>
class StampedValue
{
public:
    long stamp;
    T value;
    StampedValue() : stamp(0), value(T()) {}
    // Initial value with zero timestamp
    StampedValue(T init) : stamp(0), value(init) {}

    // Later values with timestamp provided
    StampedValue(long ts, T v) : stamp(ts), value(v) {}

    static StampedValue max(const StampedValue& x, const StampedValue& y) {
        if (x.stamp > y.stamp) {
            return x;
        } else {
            return y;
        }
    }

    static StampedValue MIN_VALUE;
};

template<typename T>
StampedValue<T> StampedValue<T>::MIN_VALUE(nullptr);



//////////////////GLOBAL VARIABLES ////////////////////
int numThreads;
const int arraySize = 16; // Change this manually and make t equal to numThreads value which you will pass in input file
StampedValue<int> a_table[arraySize];
int x;
int k=6000; // num of operations per thread
int lambda;
int timetaken=0;
std::ofstream outputFile1("logfile.txt");
///////// ///////////////////////////////////////////



class mrmw
{
    public:
     int read()
     {
       StampedValue<int> maxValue = a_table[0];
    
       for (int i = 0; i < arraySize; i++) {
        maxValue = StampedValue<int>::max(maxValue, a_table[i]);
      }
      return maxValue.value;
     }


    void write(int tno,int value_to_write)
     {
        StampedValue<int> maxValue = a_table[0];
    
       for (int i = 0; i < arraySize; ++i) {
        maxValue = StampedValue<int>::max(maxValue, a_table[i]);
      }
    a_table[tno]=StampedValue<int>(maxValue.stamp+1, value_to_write);
      
     }
     
};

class Params
{
  public:
    int threadNo;
    Params(int inThreadNo):
    threadNo(inThreadNo){}
};

void *testAtomic(void *param)
{
   Params *p = (class Params *)param;
   int tno = p->threadNo; // Each thread got integer thread id
   
   mrmw obj; // object of MRMW class 
   std::default_random_engine uniRandGen(std::chrono::system_clock::now().time_since_epoch().count());
   std::default_random_engine expRandGen(std::chrono::system_clock::now().time_since_epoch().count());
   std::uniform_real_distribution<double> uniRandDist(0.0, 1.0);
   std::exponential_distribution<double> expRandDist(lambda);
    double p_rand;
    for (int i = 0; i < k ; i++)
    {
      
         p_rand = uniRandDist(uniRandGen);
         auto startTime = std::chrono::high_resolution_clock::now();
          if (p_rand < 0.5) 
          {
            auto reqtime = chrono::system_clock::to_time_t(chrono::system_clock::now());
            
            outputFile1 <<i<< "th Action requested at "<< ctime(&reqtime)<<" by thread id "<<tno<<endl;
            
            obj.write(tno,tno*k);
            outputFile1<<"value writen "<<tno*k<<endl;
            auto compltime = chrono::system_clock::to_time_t(chrono::system_clock::now());
            
            outputFile1 <<i<< "th Action completed at "<< ctime(&compltime)<<" by thread id "<<tno<<endl;
            
          }
          else
          {
            auto reqtime = chrono::system_clock::to_time_t(chrono::system_clock::now());
            outputFile1 <<i<< "th Action requested at "<< ctime(&reqtime)<<" by thread id "<<tno<<endl;
            x=obj.read();
            outputFile1<<"value read "<<x<<endl;
            auto compltime = chrono::system_clock::to_time_t(chrono::system_clock::now());
            outputFile1 <<i<< "th Action completed at "<< ctime(&compltime)<<" by thread id "<<tno<<endl;              
          } 
          auto endTime = std::chrono::high_resolution_clock::now();
          timetaken += std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();
           
          double sleepTime = expRandDist(expRandGen);
          usleep(static_cast<unsigned int>(sleepTime * 1000));

    }
}

int main()
{
   
   for (int i = 0; i < arraySize; ++i) 
    {
        a_table[i] = StampedValue<int>(0);
       
    }
  ////////////READING FROM INP-PARAMS.TXT/////////////////
	fstream in ; in .open("inp-params.txt", fstream:: in);

	if (! in .is_open())
	{
		cerr << "Input file not open\n";
		return 0;
	} in >> numThreads >> k>> lambda;
	
	in .close();
  /////////////////////////////////////////////////////////

  ///////////////////////MULTI THREADING////////////////////
    pthread_t threads[numThreads];

    for( int i = 0; i <numThreads; i++ ) 
    {
      Params *p = new Params(i); 
      pthread_create(&threads[i], NULL ,testAtomic,p);
      
    }
   for(int i = 0; i < numThreads; i++) 
    {
        pthread_join(threads[i],NULL);    
    }
    //////////////////////////////////////////////////////

   cout<< timetaken;
    return 0;
}
