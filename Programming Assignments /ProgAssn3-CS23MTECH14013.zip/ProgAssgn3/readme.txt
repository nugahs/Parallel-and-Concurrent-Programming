How to run the programs using terminal?

Set the path to where the program file is 

To compile use the command :
g++ -std=c++20 -pthread <filename>.cpp

To run use the command :
./a.out
 

// log file will be generated 

One thing has to be set manually in the code and that is the value of global paramter
"arraysize" and it should be set equal to the numberof threads/ capacity which you send in 
input file .
