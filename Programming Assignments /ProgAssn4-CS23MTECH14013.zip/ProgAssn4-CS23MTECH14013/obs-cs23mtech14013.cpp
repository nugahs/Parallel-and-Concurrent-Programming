#include <iostream>
#include <vector>
#include <atomic>
#include <pthread.h>
#include <random>
#include <chrono>
#include <unistd.h>
#include <array>
#include <ctime>
#include <fstream>

using namespace std;
using namespace chrono;

//////////////////    GLOBAL VARIABLES   //////////////////
int nw;
int M;
int ns; // number of snapshot threads
float averageSleepTime;
float averageSleepTimeSnapshot;
int k;
std::atomic<bool> term(false); // Global atomic variable with boolean data type
double total_scan_time=0.0;
double total_update_time=0.0;
int update_counter=0;
int scan_counter=0;
double worst_scan_time=0.0;
double worst_update_time=0.0;
///////////////////////////////////////////////////////

template <typename T>
class StampedValue
{
public:
    long stamp;
    T value;
    StampedValue() : stamp(0), value(T()) {}
    // Initial value with zero timestamp
    StampedValue(T init) : stamp(0), value(init) {}
    // Later values with timestamp provided
    StampedValue(long ts, T v) : stamp(ts), value(v) {}

    static StampedValue max(const StampedValue& x, const StampedValue& y) {
        if (x.stamp > y.stamp) {
            return x;
        } else {
            return y;
        }
    }

    static StampedValue MIN_VALUE;
    
};

template<typename T>
StampedValue<T> StampedValue<T>::MIN_VALUE(nullptr);

//////////////////    SHARED OBJECT       /////////////////////
std::vector<std::atomic<StampedValue<int> > > atomicVector(90);
///////////////////////////////////////////////////////////////

class Params
{
  public:
    int threadNo;
    Params(int inThreadNo):
    threadNo(inThreadNo)
    {}
};



void *writer(void *param) 
{
    Params *p = (class Params *)param;
    int tno = p->threadNo;

    std::exponential_distribution<> expDist(1.0 / averageSleepTime);
    while (!term) 
    {
        // Generate random index and random value
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> indexDist(0, M - 1);
        std::uniform_int_distribution<> valueDist(1, 100); // Random values from 0 to 100

        int randomIndex = indexDist(gen);
        int randomValue = valueDist(gen);
        
        auto startTime = std::chrono::high_resolution_clock::now();
        ///////// Update the random value at the random index
        StampedValue<int> maxValue = atomicVector[0];
        for (int i = 0; i < M; ++i) 
        {
        maxValue = StampedValue<int>::max(maxValue, atomicVector[i]);
        }
        StampedValue<int> tempStampedValueObj = atomicVector[randomIndex].load();        
        //tempStampedValueObj.value = randomValue;
        maxValue = StampedValue<int>::max(maxValue, tempStampedValueObj.stamp);
        atomicVector[randomIndex]=StampedValue<int>((maxValue.stamp+1),randomValue);
        ///////////////////////////////////////////////////////////////

         auto endTime = std::chrono::high_resolution_clock::now();

        // capturing current time 
        auto currentTime = std::chrono::system_clock::now();
        std::time_t time = std::chrono::system_clock::to_time_t(currentTime);
        // Convert time_t to local time and format it as a string
        char buffer[80];
        std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", std::localtime(&time));

        cout << "Thr" << tno <<" s write of "<< randomValue <<" on location " << randomIndex<<" at "<< buffer<<endl;
        
        double t1 = expDist(gen);
        usleep(static_cast<unsigned int>(t1*1000));
        update_counter++;
        total_update_time += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
        double temp= duration_cast<nanoseconds>(endTime - startTime).count();
        if(temp >worst_update_time)
        worst_update_time =temp;
    }
    return nullptr; 
}


template<typename T>
std::vector<StampedValue<T> > collect() 
{
    std::vector<StampedValue<T> > copy;
    for (int i = 0; i < M; ++i) 
    {
        StampedValue<T> value = atomicVector[i].load();
        copy.push_back(value);
    }
    return copy;
}


template<typename T>
std::vector<int> scan() 
{
    std::vector<StampedValue<T> > oldCopy = collect<T>();
    std::vector<StampedValue<T> > newCopy;
    

    while (true) 
    {
        newCopy = collect<T>();

       // bool equal = true;
        for (size_t i = 0; i < M; ++i) 
        {
            if (oldCopy[i].stamp != newCopy[i].stamp) 
            {
                oldCopy = newCopy;
                continue;
            }
        }
        std::vector<int> result;

        for (const auto& item : newCopy) 
        {
            result.push_back(item.value);
        }

        return result;
    }
}


void *snapshot(void *param) 
{
    Params *p = (class Params *)param;
    int tno = p->threadNo;
    int i=0;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::exponential_distribution<> expDist(1.0 / averageSleepTimeSnapshot);
    while(i<k)
    {
        auto startTime = std::chrono::high_resolution_clock::now();
        std::vector<int> scannedValues = scan<int>();
        auto endTime = std::chrono::high_resolution_clock::now();
        scan_counter++;
        total_scan_time += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();
        // capturing current time 
        auto currentTime = std::chrono::system_clock::now();
        std::time_t time = std::chrono::system_clock::to_time_t(currentTime);
        // Convert time_t to local time and format it as a string
        char buffer[80];
        std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", std::localtime(&time));
        double temp= duration_cast<nanoseconds>(endTime - startTime).count();
        if(temp >worst_scan_time)
        worst_scan_time =temp;
        // Print the scannedValues
        cout << "Snapshot Thr " << tno <<" ’s snapshot: ";
        int l=0;// location 
        for (const auto& value : scannedValues) 
        {
        cout << "l" << l <<"- "<<value << " ";
        l++;
        }
        cout <<"which finished at "<< buffer << endl;
        
       double t2 = expDist(gen);
       usleep(static_cast<unsigned int>(t2*1000));
       i++;
    }
    

}

void compute_stats()
{
    double avg_scanning_time =  total_scan_time/scan_counter;
    double avg_updating_time =  total_update_time/update_counter;
    double avg_all_ops_time = (total_scan_time+total_update_time)/(scan_counter+update_counter);

    cout<< "Average scanning time "<< avg_scanning_time << " nano seconds "<<endl;
    cout<< "Average updating time "<< avg_updating_time << " nano seconds "<<endl;
    cout<< "Average time for all operations "<< avg_all_ops_time << " nano seconds "<<endl;
    cout<< "Worst case scan time "<< worst_scan_time << " nano seconds "<<endl;
    cout<< "Worst case update time "<< worst_update_time << " nano seconds "<<endl;

}
int main() 
{
    ////////////Reading from file/////////////
    fstream in;
    in.open("inp-params.txt", fstream::in);

    if(!in.is_open()) {
        cerr<<"Input file not open\n";
         return 0;
    }
    in>>nw >> ns>> M>>averageSleepTime>>averageSleepTimeSnapshot>> k;
         // reading from "input.txt"
    in.close();
    ////////////////////////////////////////////
    
    
    term.store(false);
   
    // Create a temporary vector of atomic objects
    std::vector<std::atomic<StampedValue<int> > > tempAtomicVector(M);
    for (int i = 0; i < M; ++i) 
    {
        tempAtomicVector[i].store(StampedValue<int>(0), std::memory_order_relaxed);
    }

    // Swap the temporary vector with atomicVector
    atomicVector.swap(tempAtomicVector);


    ////////////////////////    MULTI THREADING    /////////////////////////
   
    pthread_t threads[nw];  //CREATING WRITER THREADS 

    for (int i = 0; i < nw; ++i) 
    {
         Params *p = new Params(i); 
        pthread_create(&threads[i], NULL, writer,p);
    }
    
    pthread_t snapthreads[ns]; //CREATING SNAPSHOT THREADS 
    for (int i = 0; i < ns; ++i) 
    {
        Params *s = new Params(i); 
        pthread_create(&snapthreads[i], NULL, snapshot,s);
    }
    for (int i = 0; i < ns; ++i) 
    {
        pthread_join(snapthreads[i], nullptr);
    }
    
    term.store(true); // Set the termination condition

    // Wait for writer threads to complete
    for (int i = 0; i < nw; ++i)
    {
        pthread_join(threads[i], nullptr);
    }
    /////////////////////////////////////////////////////////////////
    compute_stats();

    return 0;
}