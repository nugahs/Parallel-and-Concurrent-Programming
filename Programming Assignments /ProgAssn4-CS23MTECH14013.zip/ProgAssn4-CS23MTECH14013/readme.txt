How to run the programs using terminal?

Set the path to where the program file is 

To compile use the command :
g++ -std=c++20 -pthread <filename>.cpp

To run use the command :
./a.out
 
Device on which I have run the programs:
MacBook Air M2 
8 cores 
