#include <iostream>
#include <vector>
#include <atomic>
#include <random>
#include <chrono>
#include <unistd.h>
#include <fstream>
using namespace std;
using namespace chrono;

// Define the structure for REG
struct MyStruct 
{
    int val;
    int pid;
    int sn;
};

// Structure to hold the vector pointer
struct struct2 
{
    std::vector<MyStruct>* data;
};

//////////////////    GLOBAL VARIABLES   //////////////////
int nw;
int M;
int ns; // number of snapshot threads
float averageSleepTime;
float averageSleepTimeSnapshot;
int k;
std::atomic<bool> term(false); // Global atomic variable with boolean data type
// Global atomic variable of type struct2
std::atomic<struct2> REG;
std::vector<std::vector<int> * > HELPSNAP;
double total_scan_time=0.0;
double total_update_time=0.0;
int update_counter=0;
int scan_counter=0;
double worst_scan_time=0.0;
double worst_update_time=0.0;
///////////////////////////////////////////////////////

std::vector<int> scan()
{
  // std::vector<int> can_help;
   std::vector<int> can_help(1000, -1); 
   std::vector<MyStruct> aa;
   struct2 currentData = REG.load();
   aa = *currentData.data;
   std::vector<int> result;
   while(true)
        {
            std::vector<MyStruct> bb;
            struct2 currentData2 = REG.load();
            bb = *currentData2.data;
            bool equal = true;
            for(size_t i = 0; i < aa.size(); ++i)
            {
              if(aa[i].val != bb[i].val || aa[i].pid != bb[i].pid || aa[i].sn != bb[i].sn)
              {
                equal = false;

                break;
              }
            }

             if(equal)
            {
            for(size_t i = 0; i < bb.size(); ++i)
            {
                result.push_back(bb[i].val);
            }
            return result;
            }

            for(size_t i = 0; i < aa.size(); ++i)
            {
              if(aa[i].val != bb[i].val || aa[i].pid != bb[i].pid || aa[i].sn != bb[i].sn)
              {
               int w= bb[i].pid;
               // Check if w is present in can_help
                auto it = find(can_help.begin(), can_help.end(), w);
                if (it != can_help.end()) 
                {
                    // w is present in can_help, return HELPSNAP[w]
                    return *HELPSNAP[w];
                } 
                else 
                {
                    // w is not present in can_help, add w to can_help and continue scanning
                    can_help.push_back(w);
                }
               
              }
            }
        }   
}

void update(int i,int x,int v)
{
 struct2 currentData = REG.load();
 (*currentData.data)[x].sn ++; 
 // std::cout << "sn: " << (*currentData.data)[i].sn << std::endl;
 (*currentData.data)[x].val = v;
 (*currentData.data)[x].pid = i;

  struct2 newData;
    newData.data = currentData.data;
    REG.store(newData);
    // for (size_t j = 0; j < currentData.data->size(); ++j) {
    //     std::cout << "val: " << (*currentData.data)[j].val << " ";
    //     std::cout << "pid: " << (*currentData.data)[j].pid << " ";
    //     std::cout << "sn: " << (*currentData.data)[j].sn << std::endl;
    // }
    // Store the vector returned by scan() in HELPSNAP[i]
    std::vector<int> scannedData = scan();
    HELPSNAP[i] = new std::vector<int>(scannedData);

}

class Params
{
  public:
    int threadNo;
    Params(int inThreadNo):
    threadNo(inThreadNo)
    {}
};

void *writer(void *param) 
{
    Params *p = (class Params *)param;
    int tno = p->threadNo;

    std::exponential_distribution<> expDist(1.0 / averageSleepTime);
    while (!term) 
    {
        // Generate random index and random value
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> indexDist(0, M - 1);
        std::uniform_int_distribution<> valueDist(1, 100); // Random values from 0 to 100

        int randomIndex = indexDist(gen);
        int randomValue = valueDist(gen);
        auto startTime = std::chrono::high_resolution_clock::now();
        update(tno,randomIndex,randomValue);
        auto endTime = std::chrono::high_resolution_clock::now();

        // capturing current time 
        auto currentTime = std::chrono::system_clock::now();
        std::time_t time = std::chrono::system_clock::to_time_t(currentTime);
        // Convert time_t to local time and format it as a string
        char buffer[80];
        std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", std::localtime(&time));

        double temp= duration_cast<nanoseconds>(endTime - startTime).count();
        if(temp >worst_update_time)
        worst_update_time =temp;

        cout << "Thr" << tno <<" s write of "<< randomValue <<" on location " << randomIndex<<" at "<<buffer<<endl;
        update_counter++;
        total_update_time += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();

    }
}

void *snapshot(void *param)
{
  Params *p = (class Params *)param;
    int tno = p->threadNo;
    int i=0;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::exponential_distribution<> expDist(1.0 / averageSleepTimeSnapshot);
    while(i<k)
    {
        auto startTime = std::chrono::high_resolution_clock::now();
        std::vector<int> scannedValues = scan();
        auto endTime = std::chrono::high_resolution_clock::now();
        scan_counter++;
        total_scan_time += std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTime).count();

        // capturing current time 
        auto currentTime = std::chrono::system_clock::now();
        std::time_t time = std::chrono::system_clock::to_time_t(currentTime);
        // Convert time_t to local time and format it as a string
        char buffer[80];
        std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", std::localtime(&time));
        double temp= duration_cast<nanoseconds>(endTime - startTime).count();
        if(temp >worst_scan_time)
        worst_scan_time =temp;
        cout << "Snapshot Thr " << tno <<" ’s snapshot: ";
        int l=0;// location 
        for (const auto& value : scannedValues) 
        {
        cout << "l" << l <<"- "<<value << " ";
        l++;
        }
       cout <<"which finished at "<< buffer << endl;
       double t2 = expDist(gen);
       usleep(static_cast<unsigned int>(t2*1000));
       i++;

    }
}
void compute_stats()
{
    double avg_scanning_time =  total_scan_time/scan_counter;
    double avg_updating_time =  total_update_time/update_counter;
    double avg_all_ops_time = (total_scan_time+total_update_time)/(scan_counter+update_counter);

    cout<< "Average scanning time "<< avg_scanning_time << " nano seconds "<<endl;
    cout<< "Average updating time "<< avg_updating_time << " nano seconds "<<endl;
    cout<< "Average time for all operations "<< avg_all_ops_time << " nano seconds "<<endl;
    cout<< "Worst case scan time "<< worst_scan_time << " nano seconds "<<endl;
    cout<< "Worst case update time "<< worst_update_time << " nano seconds "<<endl;

}
int main() 
{
    ////////////Reading from file/////////////
    fstream in;
    in.open("inp-params.txt", fstream::in);

    if(!in.is_open()) {
        cerr<<"Input file not open\n";
         return 0;
    }
    in>>nw >> ns>> M>>averageSleepTime>>averageSleepTimeSnapshot>> k;
         // reading from "input.txt"
    in.close();
    ////////////////////////////////////////////
    
    // Initialize HELPSNAP with empty vectors
    HELPSNAP.resize(nw);
   for (int i = 0; i < nw; ++i) 
   {
    HELPSNAP[i] = new std::vector<int>();
   }

    // Initialize the global vector with size m
    std::vector<MyStruct>* vecPtr = new std::vector<MyStruct>(M);
    struct2 initialData;
    initialData.data = vecPtr;
    REG.store(initialData);

    // Accessing elements in the vector
    // For example, setting the values of the first element atomically
    struct2 currentData = REG.load();
    for(int i=0;i<M;i++)
    {
    (*currentData.data)[i].val = 0;
    (*currentData.data)[i].pid = 0;
    (*currentData.data)[i].sn = 0;
    }
    ////////////////////////    MULTI THREADING    /////////////////////////
   
    pthread_t threads[nw];  //CREATING WRITER THREADS 

    for (int i = 0; i < nw; ++i) 
    {
         Params *p = new Params(i); 
        pthread_create(&threads[i], NULL, writer,p);
    }
    
    pthread_t snapthreads[ns]; //CREATING SNAPSHOT THREADS 
    for (int i = 0; i < ns; ++i) 
    {
        Params *s = new Params(i); 
        pthread_create(&snapthreads[i], NULL, snapshot,s);
    }
    for (int i = 0; i < ns; ++i) 
    {
        pthread_join(snapthreads[i], nullptr);
    }
    
    term.store(true); // Set the termination condition

    // Wait for writer threads to complete
    for (int i = 0; i < nw; ++i)
    {
        pthread_join(threads[i], nullptr);
    }
    /////////////////////////////////////////////////////////////////
   

    // Retrieving and printing values of the first element
    // std::cout << "val: " << (*currentData.data)[1].val << std::endl;
    // std::cout << "pid: " << (*currentData.data)[m-2].pid << std::endl;
    // std::cout << "sn: " << (*currentData.data)[m-1].sn << std::endl;

    // Clean up the allocated vector
    delete vecPtr;
    // Clean up HELPSNAP vectors
    for (int i = 0; i < nw; ++i) 
    {
    delete HELPSNAP[i];
    }

    compute_stats();
    return 0;
}
